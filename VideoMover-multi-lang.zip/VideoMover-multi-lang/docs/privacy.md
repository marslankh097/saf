# Privacy Policy — VideoMover

**Last updated:** 2025-11-07

VideoMover processes your videos locally on your device to copy/move them to a user-selected folder via Android’s Storage Access Framework (SAF).

- **Data collection:** The app does **not** collect, transmit, or store personal data on external servers.
- **Network:** The app does not require Internet connection and does not send data to us.
- **Permissions:** Access to media/files is granted by you via SAF (and kept persistently by Android only for the selected folder). On Android 13+, notification permission may be requested to show copy progress.
- **Third-party:** No third-party analytics or ads SDKs.
- **Children:** The app is not directed to children.
- **Contact:** <your public support email>

If you have questions, contact us at pasha404@gmail.com.
